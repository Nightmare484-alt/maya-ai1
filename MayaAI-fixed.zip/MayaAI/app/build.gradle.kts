plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.maya.assistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.maya.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    // Optional release signing: pass -PMAYA_KEYSTORE=/path -PMAYA_KEYSTORE_PASSWORD=... -PMAYA_KEY_ALIAS=... -PMAYA_KEY_PASSWORD=...
    val ksPath = providers.gradleProperty("MAYA_KEYSTORE").orNull
    if (ksPath != null) {
        signingConfigs.create("release") {
            storeFile = file(ksPath)
            storePassword = providers.gradleProperty("MAYA_KEYSTORE_PASSWORD").get()
            keyAlias = providers.gradleProperty("MAYA_KEY_ALIAS").get()
            keyPassword = providers.gradleProperty("MAYA_KEY_PASSWORD").get()
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (ksPath != null) signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    lint { abortOnError = false }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.1")
    testImplementation("org.json:json:20240303") // android.jar org.json is a stub on the JVM
}
