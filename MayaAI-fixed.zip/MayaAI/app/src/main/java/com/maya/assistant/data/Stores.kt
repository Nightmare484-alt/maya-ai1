package com.maya.assistant.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

interface ApiKeyStore {
    fun get(): String
    fun set(key: String)
    fun clear()
}

/** Stores the API key encrypted with a non-exportable AES key from the Android Keystore. */
class KeystoreApiKeyStore(context: Context) : ApiKeyStore {
    private val prefs = context.getSharedPreferences("maya_secure", Context.MODE_PRIVATE)

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(
                ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    override fun get(): String {
        val stored = prefs.getString(PREF, null) ?: return ""
        return try {
            val (iv, ct) = stored.split(":").map { Base64.decode(it, Base64.NO_WRAP) }
            val cipher = Cipher.getInstance(TRANSFORM)
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(ct), Charsets.UTF_8)
        } catch (e: Exception) {
            clear() // unreadable (e.g. keystore reset): drop it so the user is asked again
            ""
        }
    }

    override fun set(key: String) {
        val trimmed = key.trim()
        if (trimmed.isEmpty()) return clear()
        val cipher = Cipher.getInstance(TRANSFORM)
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val ct = cipher.doFinal(trimmed.toByteArray(Charsets.UTF_8))
        val packed = Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" +
            Base64.encodeToString(ct, Base64.NO_WRAP)
        prefs.edit().putString(PREF, packed).apply()
    }

    override fun clear() {
        prefs.edit().remove(PREF).apply()
    }

    private companion object {
        const val ALIAS = "maya_api_key"
        const val PREF = "api_key_enc"
        const val TRANSFORM = "AES/GCM/NoPadding"
    }
}

interface SettingsStore {
    var settings: MayaSettings
    var micPermissionAsked: Boolean
    fun clear()
}

class PrefsSettingsStore(context: Context) : SettingsStore {
    private val prefs = context.getSharedPreferences("maya_settings", Context.MODE_PRIVATE)

    override var settings: MayaSettings
        get() {
            val d = MayaSettings()
            return MayaSettings(
                userName = prefs.getString("name", d.userName) ?: d.userName,
                model = (prefs.getString("model", d.model) ?: d.model).let { if (it.isBlank() || it.startsWith("claude")) d.model else it },
                webSearch = prefs.getBoolean("web", d.webSearch),
                speakReplies = prefs.getBoolean("speak", d.speakReplies),
            )
        }
        set(v) {
            prefs.edit().putString("name", v.userName).putString("model", v.model)
                .putBoolean("web", v.webSearch).putBoolean("speak", v.speakReplies).apply()
        }

    override var micPermissionAsked: Boolean
        get() = prefs.getBoolean("mic_asked", false)
        set(v) { prefs.edit().putBoolean("mic_asked", v).apply() }

    override fun clear() {
        prefs.edit().clear().apply()
    }
}
