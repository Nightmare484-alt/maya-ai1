package com.maya.assistant.voice

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import com.maya.assistant.data.ApiKeyStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64

/**
 * Natural voice via Gemini TTS, reusing the existing Gemini API key. Falls back to the system
 * [fallback] speaker if there is no key, the request fails (quota, network, model change), or
 * nothing could be played before the failure.
 */
class GeminiSpeaker(
    private val keys: ApiKeyStore,
    private val fallback: Speaker,
    private val model: String = DEFAULT_MODEL,
    private val voice: String = DEFAULT_VOICE,
    private val baseUrl: String = "https://generativelanguage.googleapis.com/v1beta",
) : Speaker {
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    @Volatile private var track: AudioTrack? = null

    override fun speak(text: String, onDone: () -> Unit) {
        stop()
        val key = keys.get()
        if (key.isBlank() || text.isBlank()) return fallback.speak(text, onDone)
        job = scope.launch {
            var played = false
            var next: kotlinx.coroutines.Deferred<ByteArray>? = null
            try {
                val chunks = chunk(text)
                // Prefetch: synthesize chunk N+1 while chunk N plays.
                next = scope.async { synth(key, chunks[0]) }
                for (i in chunks.indices) {
                    val pcm = next!!.await()
                    if (i + 1 < chunks.size) next = scope.async { synth(key, chunks[i + 1]) }
                    play(pcm)
                    played = true
                }
                main.post(onDone)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                // Never leave the UI stuck in SPEAKING.
                if (played) main.post(onDone) else main.post { fallback.speak(text, onDone) }
            } finally {
                next?.cancel()
            }
        }
    }

    private fun synth(key: String, text: String): ByteArray {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject()
                .put("text", "Say warmly and naturally, like a friendly person talking: $text")))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject()
                    .put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
            .toString()
        val conn = URL("$baseUrl/models/$model:generateContent").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 45_000
            conn.doOutput = true
            conn.setRequestProperty("x-goog-api-key", key)
            conn.setRequestProperty("content-type", "application/json")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val resp = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) error("tts http $code")
            return parsePcm(resp)
        } finally {
            conn.disconnect()
        }
    }

    private suspend fun play(pcm: ByteArray) = withContext(Dispatchers.IO) {
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setTransferMode(AudioTrack.MODE_STATIC)
            .setBufferSizeInBytes(pcm.size)
            .build()
        track = t
        try {
            t.write(pcm, 0, pcm.size)
            t.play()
            val frames = pcm.size / 2
            val deadline = System.currentTimeMillis() + frames * 1000L / SAMPLE_RATE + 2_000
            while (isActive && t.playbackHeadPosition < frames && System.currentTimeMillis() < deadline) delay(40)
        } finally {
            track = null
            try { t.stop() } catch (_: IllegalStateException) {}
            t.release()
        }
    }

    override fun stop() {
        job?.cancel()
        job = null
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
        fallback.stop()
    }

    override fun release() {
        stop()
        scope.cancel()
        fallback.release()
    }

    companion object {
        const val DEFAULT_MODEL = "gemini-2.5-flash-preview-tts"
        const val DEFAULT_VOICE = "Aoede"
        const val SAMPLE_RATE = 24_000
        private const val MAX_CHUNK = 700

        /** Splits on sentence boundaries into chunks small enough for fast TTS responses. */
        fun chunk(text: String): List<String> {
            val out = mutableListOf<String>()
            val cur = StringBuilder()
            for (s in text.split(Regex("(?<=[.!?])\\s+"))) {
                if (cur.isNotEmpty() && cur.length + s.length > MAX_CHUNK) { out += cur.toString(); cur.clear() }
                var part = s
                while (part.length > MAX_CHUNK) { out += part.take(MAX_CHUNK); part = part.drop(MAX_CHUNK) }
                if (cur.isNotEmpty()) cur.append(' ')
                cur.append(part)
            }
            if (cur.isNotBlank()) out += cur.toString()
            return out.ifEmpty { listOf(text) }
        }

        /** Extracts base64 16-bit PCM (24 kHz mono) from a generateContent response. */
        fun parsePcm(json: String): ByteArray {
            val parts = JSONObject(json).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            for (i in 0 until parts.length()) {
                val data = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data").orEmpty()
                if (data.isNotEmpty()) return Base64.getDecoder().decode(data)
            }
            error("no audio in response")
        }
    }
}
