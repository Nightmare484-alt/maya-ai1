package com.maya.assistant.actions

sealed interface LocalCommand {
    data class OpenApp(val name: String) : LocalCommand
    data class YouTube(val query: String) : LocalCommand
    data class WebSearch(val query: String) : LocalCommand
    data class Timer(val seconds: Int) : LocalCommand
    data class Remember(val fact: String) : LocalCommand
}

/** Pure, offline matching of a small set of explicit commands. Everything else goes to the AI. */
object CommandRouter {
    private val wake = Regex("^(?:(?:hey|hi|ok|okay)\\s+)?maya[,:]?\\s+", RegexOption.IGNORE_CASE)
    private val trailing = Regex("[\\s.!?]+$")

    private val remember = Regex("^(?:please\\s+)?remember(?:\\s+that)?\\s+(.+)$", RegexOption.IGNORE_CASE)
    private val openApp = Regex("^(?:please\\s+)?(?:open|launch|start)\\s+(?:the\\s+)?(.+?)(?:\\s+app)?$", RegexOption.IGNORE_CASE)
    private val ytOn = Regex("^(?:play|search|find|watch|search for)\\s+(.+?)\\s+(?:on|in)\\s+youtube$", RegexOption.IGNORE_CASE)
    private val ytFirst = Regex("^(?:search\\s+)?youtube(?:\\s+search)?(?:\\s+for)?\\s+(.+)$", RegexOption.IGNORE_CASE)
    private val google = Regex("^(?:google|search google for)\\s+(.+)$", RegexOption.IGNORE_CASE)
    private val timerWord = Regex("\\btimer\\b", RegexOption.IGNORE_CASE)
    private val duration = Regex("(\\d{1,4})\\s*(hours?|hrs?|h|minutes?|mins?|m|seconds?|secs?|s)\\b", RegexOption.IGNORE_CASE)

    fun route(raw: String): LocalCommand? {
        val text = raw.trim().replace(wake, "").replace(trailing, "").trim()
        if (text.isEmpty()) return null

        remember.matchEntire(text)?.let { return LocalCommand.Remember(it.groupValues[1].trim()) }

        if (timerWord.containsMatchIn(text)) {
            val m = duration.find(text) ?: return null
            val n = m.groupValues[1].toInt()
            val seconds = when (m.groupValues[2].lowercase().first()) {
                'h' -> n * 3600
                'm' -> n * 60
                else -> n
            }
            return if (seconds in 1..86_400) LocalCommand.Timer(seconds) else null
        }

        (ytOn.matchEntire(text) ?: ytFirst.matchEntire(text))?.let {
            return LocalCommand.YouTube(it.groupValues[1].trim())
        }
        google.matchEntire(text)?.let { return LocalCommand.WebSearch(it.groupValues[1].trim()) }
        openApp.matchEntire(text)?.let {
            val name = it.groupValues[1].trim()
            // Short names only: "open a bank account and tell me how" is a question, not an app.
            if (name.isNotEmpty() && name.split(" ").size <= 3) return LocalCommand.OpenApp(name)
        }
        return null
    }
}
