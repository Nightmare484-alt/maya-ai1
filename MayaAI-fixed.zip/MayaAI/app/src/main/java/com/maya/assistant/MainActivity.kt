package com.maya.assistant

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.maya.assistant.capture.ImageUtils
import com.maya.assistant.capture.ScreenCaptureService
import com.maya.assistant.ui.AppsSheet
import com.maya.assistant.ui.HomeScreen
import com.maya.assistant.ui.MayaTheme
import com.maya.assistant.ui.MemoryScreen
import com.maya.assistant.ui.SettingsScreen
import com.maya.assistant.vm.MayaViewModel
import com.maya.assistant.vm.MicAction
import com.maya.assistant.vm.Phase
import com.maya.assistant.vm.UiError
import com.maya.assistant.vm.decideMicAction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    private val vm: MayaViewModel by viewModels { MayaViewModel.factory(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        setContent { MayaTheme { MayaRoot(vm, this) } }
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
                .launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        // Keep the foreground service in step with real work. Collected for the activity's whole
        // life (not just while visible) so it also reacts after you switch apps.
        lifecycleScope.launch {
            vm.state.map { it.phase }.distinctUntilChanged().collect { phase ->
                when (phase) {
                    Phase.THINKING -> AssistantService.show(applicationContext, "Thinking…")
                    Phase.SPEAKING -> AssistantService.show(applicationContext, "Speaking…")
                    else -> AssistantService.hide(applicationContext)
                }
            }
        }
    }

    override fun onStart() { super.onStart(); vm.setAppForeground(true) }
    override fun onStop() { super.onStop(); vm.setAppForeground(false) }
    override fun onDestroy() {
        super.onDestroy()
        if (!isChangingConfigurations) AssistantService.hide(applicationContext)
    }
}

private enum class Screen { HOME, SETTINGS, MEMORY }

private const val MAX_FILE_CHARS = 20_000

@Composable
private fun MayaRoot(vm: MayaViewModel, activity: ComponentActivity) {
    val state by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    var showApps by rememberSaveable { mutableStateOf(false) }
    var showRationale by rememberSaveable { mutableStateOf(false) }
    var showMicBlocked by rememberSaveable { mutableStateOf(false) }
    var showScreenInfo by rememberSaveable { mutableStateOf(false) }

    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }

    // --- microphone ---------------------------------------------------------------------------
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            vm.startListening()
        } else {
            val blocked = !ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.RECORD_AUDIO)
            vm.micPermissionDenied(blocked)
        }
    }
    val onMic: () -> Unit = {
        if (state.phase == Phase.SPEAKING) {
            vm.stopSpeaking()
        } else {
            val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            val rationale = ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.RECORD_AUDIO)
            when (decideMicAction(granted, rationale, vm.micPermissionAsked)) {
                MicAction.START -> vm.startListening()
                MicAction.REQUEST -> {
                    vm.markMicAsked()
                    micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
                MicAction.SHOW_RATIONALE -> showRationale = true
                MicAction.OPEN_SETTINGS -> showMicBlocked = true
            }
        }
    }
    val openAppSettings: () -> Unit = {
        ctx.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null))
        )
    }

    // --- camera (system camera app: no CAMERA permission needed) -----------------------------------
    val photoFile = remember { File(File(ctx.cacheDir, "images").apply { mkdirs() }, "capture.jpg") }
    val photoUri = remember { FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", photoFile) }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) {
            scope.launch {
                val jpeg = withContext(Dispatchers.IO) { ImageUtils.decodePhoto(photoFile).also { photoFile.delete() } }
                if (jpeg != null) vm.submitImage(jpeg) else vm.reportError(UiError.PHOTO_FAILED)
            }
        } else {
            photoFile.delete()
        }
    }
    val onCamera: () -> Unit = {
        try {
            photoFile.createNewFile()
            cameraLauncher.launch(photoUri)
        } catch (e: ActivityNotFoundException) {
            vm.reportError(UiError.NO_CAMERA_APP)
        }
    }

    // --- screen share (MediaProjection, one screenshot) ----------------------------------------------
    val projectionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        if (res.resultCode == Activity.RESULT_OK && data != null) {
            vm.screenCaptureStarting()
            ScreenCaptureService.start(ctx, res.resultCode, data)
        } else {
            vm.screenCaptureDenied()
        }
    }

    // --- files (system picker: no storage permission needed) ------------------------------------------
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val file = withContext(Dispatchers.IO) { readTextFile(ctx, uri) }
                if (file != null) vm.submitFile(file.first, file.second) else vm.reportError(UiError.FILE_FAILED)
            }
        }
    }
    val pickFile: () -> Unit = { filePicker.launch(arrayOf("text/*", "application/json", "application/xml")) }

    when (screen) {
        Screen.HOME -> HomeScreen(
            state = state,
            onMic = { onMic() },
            onCamera = { onCamera() },
            onScreen = { showScreenInfo = true },
            onApps = { showApps = true },
            onSettings = { screen = Screen.SETTINGS },
            onProfile = { screen = Screen.MEMORY },
            onSendText = vm::submitText,
            onDismissError = vm::dismissError,
            onAppSettings = { openAppSettings() },
        )
        Screen.SETTINGS -> SettingsScreen(
            state = state,
            onBack = { screen = Screen.HOME },
            onName = { n -> vm.updateSettings { it.copy(userName = n) } },
            onModel = { m -> vm.updateSettings { it.copy(model = m) } },
            onWebSearch = { w -> vm.updateSettings { it.copy(webSearch = w) } },
            onSpeak = { s -> vm.updateSettings { it.copy(speakReplies = s) } },
            onSaveKey = vm::saveApiKey,
            onClearKey = vm::clearApiKey,
            onRefreshModels = vm::refreshModels,
            onTestModel = vm::testSelectedModel,
            onOpenMemory = { screen = Screen.MEMORY },
            onNewConversation = vm::newConversation,
            onDeleteAll = vm::deleteAllData,
        )
        Screen.MEMORY -> MemoryScreen(
            state = state,
            onBack = { screen = Screen.HOME },
            onAdd = vm::addNote,
            onRemove = vm::removeNote,
            onClear = vm::clearNotes,
        )
    }

    if (showApps) {
        AppsSheet(
            loadApps = vm::launchableApps,
            onLaunch = { app ->
                showApps = false
                vm.launchApp(app.packageName)
            },
            onPickFile = {
                showApps = false
                pickFile()
            },
            onDismiss = { showApps = false },
        )
    }

    if (showRationale) {
        AlertDialog(
            onDismissRequest = { showRationale = false },
            title = { Text("Microphone access") },
            text = { Text("Maya uses the microphone only while you've tapped Tap to Talk, to turn your voice into text. You can always type instead.") },
            confirmButton = {
                TextButton(onClick = {
                    showRationale = false
                    micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }) { Text("Continue") }
            },
            dismissButton = { TextButton(onClick = { showRationale = false }) { Text("Not now") } },
        )
    }

    if (showMicBlocked) {
        AlertDialog(
            onDismissRequest = { showMicBlocked = false },
            title = { Text("Microphone is blocked") },
            text = { Text("Android won't ask again. Open the app's settings and allow the microphone, or use the keyboard button to type to Maya.") },
            confirmButton = {
                TextButton(onClick = {
                    showMicBlocked = false
                    openAppSettings()
                }) { Text("Open settings") }
            },
            dismissButton = { TextButton(onClick = { showMicBlocked = false }) { Text("Cancel") } },
        )
    }

    if (showScreenInfo) {
        AlertDialog(
            onDismissRequest = { showScreenInfo = false },
            title = { Text("Share your screen once?") },
            text = {
                Text(
                    "Android will ask you to allow screen capture. After you allow it, switch to the screen you want " +
                        "Maya to see. She takes ONE screenshot about 5 seconds later, sends it to the AI to answer you, " +
                        "then stops. Nothing is recorded or saved. Pick \"A single app\" in Android's prompt if you prefer."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showScreenInfo = false
                    val mgr = ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    projectionLauncher.launch(mgr.createScreenCaptureIntent())
                }) { Text("Continue") }
            },
            dismissButton = { TextButton(onClick = { showScreenInfo = false }) { Text("Cancel") } },
        )
    }
}

/** Returns (displayName, first 20k chars) of a plain-text document, or null if unreadable/binary. */
private fun readTextFile(context: Context, uri: Uri): Pair<String, String>? = try {
    val name = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "file"
    val text = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { r ->
        val buf = CharArray(MAX_FILE_CHARS)
        val n = r.read(buf)
        if (n <= 0) "" else String(buf, 0, n)
    }
    if (text == null || text.contains('\u0000')) null else name to text
} catch (e: Exception) {
    null
}
