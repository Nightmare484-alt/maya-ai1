package com.maya.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.maya.assistant.actions.AppEntry
import com.maya.assistant.vm.Check
import com.maya.assistant.vm.UiState

@Composable
private fun ScreenScaffold(title: String, onBack: () -> Unit, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        content()
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = MayaCyan, modifier = Modifier.padding(top = 20.dp, bottom = 6.dp))
}

@Composable
private fun CheckLine(check: Check, idle: String?) {
    val text = when {
        check.running -> "Checking…"
        check.ok != null -> check.ok
        check.error != null -> check.error.message()
        else -> idle
    } ?: return
    Text(text, fontSize = 13.sp, color = if (check.error != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(top = 4.dp))
}

@Composable
fun SettingsScreen(
    state: UiState,
    onBack: () -> Unit,
    onName: (String) -> Unit,
    onModel: (String) -> Unit,
    onWebSearch: (Boolean) -> Unit,
    onSpeak: (Boolean) -> Unit,
    onSaveKey: (String) -> Unit,
    onClearKey: () -> Unit,
    onRefreshModels: () -> Unit,
    onTestModel: () -> Unit,
    onOpenMemory: () -> Unit,
    onNewConversation: () -> Unit,
    onDeleteAll: () -> Unit,
) {
    var key by rememberSaveable { mutableStateOf("") }
    var showKey by rememberSaveable { mutableStateOf(false) }
    var pickModel by remember { mutableStateOf(false) }
    var confirmDelete by rememberSaveable { mutableStateOf(false) }

    ScreenScaffold("Settings", onBack) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            SectionTitle("AI provider (Google Gemini)")
            Text(
                if (state.hasApiKey) "A key is saved. It is stored encrypted on this device only."
                else "No key yet. Create one at aistudio.google.com/apikey and paste it below.",
                fontSize = 14.sp,
            )
            Spacer(Modifier.size(8.dp))
            OutlinedTextField(
                value = key,
                onValueChange = { key = it },
                label = { Text("API key") },
                singleLine = true,
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = { TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Hide" else "Show") } },
                modifier = Modifier.fillMaxWidth(),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                Button(onClick = { onSaveKey(key); key = "" }, enabled = key.isNotBlank()) { Text("Save key") }
                if (state.hasApiKey) OutlinedButton(onClick = onClearKey) { Text("Remove key") }
            }
            if (state.hasApiKey) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                    OutlinedButton(onClick = onRefreshModels, enabled = !state.connection.running) { Text("Test connection") }
                    OutlinedButton(onClick = onRefreshModels, enabled = !state.connection.running) { Text("Refresh models") }
                }
                CheckLine(state.connection, idle = "Not tested yet.")
            }
            Spacer(Modifier.size(8.dp))
            OutlinedTextField(
                value = state.settings.model,
                onValueChange = onModel,
                label = { Text("Model") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            if (state.models.isNotEmpty()) {
                Box {
                    OutlinedButton(onClick = { pickModel = true }) { Text("Choose from ${state.models.size} available models") }
                    DropdownMenu(expanded = pickModel, onDismissRequest = { pickModel = false }) {
                        state.models.forEach { m ->
                            DropdownMenuItem(
                                text = { Text(if (m.displayName == m.id) m.id else "${m.displayName} (${m.id})", fontSize = 13.sp) },
                                onClick = { onModel(m.id); pickModel = false },
                            )
                        }
                    }
                }
                if (state.models.none { it.id == state.settings.model.removePrefix("models/") }) {
                    Text("This model isn't in your available list. It may be retired or not enabled for your key.", fontSize = 13.sp, color = MaterialTheme.colorScheme.error)
                }
            }
            if (state.hasApiKey) {
                OutlinedButton(onClick = onTestModel, enabled = !state.modelCheck.running, modifier = Modifier.padding(top = 4.dp)) { Text("Test selected model") }
                CheckLine(state.modelCheck, idle = null)
            }
            SwitchRow("Let Maya search the web", "Sends the question to the provider's web search tool.", state.settings.webSearch, onWebSearch)

            SectionTitle("You")
            OutlinedTextField(
                value = state.settings.userName,
                onValueChange = onName,
                label = { Text("Your name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            SwitchRow("Speak replies aloud", "Uses your phone's text-to-speech voice.", state.settings.speakReplies, onSpeak)

            SectionTitle("Memory and privacy")
            Text(
                "Maya only remembers what you ask her to (say \"remember that…\"). Notes stay on this phone and " +
                    "are sent to the AI provider with your questions so it can use them.",
                fontSize = 14.sp,
            )
            OutlinedButton(onClick = onOpenMemory, modifier = Modifier.padding(top = 8.dp)) {
                Text("Manage memory (${state.notes.size})")
            }
            OutlinedButton(onClick = onNewConversation, modifier = Modifier.padding(top = 8.dp)) { Text("Start a new conversation") }
            Text(
                "Voice is processed by your phone's speech service. Photos and screenshots are sent to the AI " +
                    "provider only when you tap Camera or Screen, and are never saved by Maya.",
                fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp),
            )
            HorizontalDivider(Modifier.padding(vertical = 16.dp))
            OutlinedButton(onClick = { confirmDelete = true }) { Text("Delete all Maya data") }
            Spacer(Modifier.size(32.dp))
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete all data?") },
            text = { Text("This removes your API key, memory notes, settings and the current conversation.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; onDeleteAll() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun MemoryScreen(
    state: UiState,
    onBack: () -> Unit,
    onAdd: (String) -> Unit,
    onRemove: (Long) -> Unit,
    onClear: () -> Unit,
) {
    var text by rememberSaveable { mutableStateOf("") }
    ScreenScaffold("Memory", onBack) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            Text("Things Maya remembers about you. Delete any time.", fontSize = 14.sp)
            Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = text, onValueChange = { text = it }, singleLine = true,
                    label = { Text("Add a note") }, modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.size(8.dp))
                Button(onClick = { onAdd(text); text = "" }, enabled = text.isNotBlank()) { Text("Add") }
            }
            if (state.notes.isEmpty()) {
                Text("Nothing yet. Try saying \"Maya, remember that I prefer short answers\".", fontSize = 14.sp)
            } else {
                LazyColumn(Modifier.weight(1f)) {
                    items(state.notes, key = { it.id }) { note ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(note.text, modifier = Modifier.weight(1f).padding(vertical = 10.dp))
                            IconButton(onClick = { onRemove(note.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete note")
                            }
                        }
                        HorizontalDivider()
                    }
                }
                TextButton(onClick = onClear) { Text("Clear all notes") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppsSheet(
    loadApps: () -> List<AppEntry>,
    onLaunch: (AppEntry) -> Unit,
    onPickFile: () -> Unit,
    onDismiss: () -> Unit,
) {
    val apps = remember { loadApps() }
    var query by rememberSaveable { mutableStateOf("") }
    val shown = remember(query, apps) { apps.filter { it.label.contains(query.trim(), ignoreCase = true) } }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 16.dp).navigationBarsPadding()) {
            Text("Apps & Files", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(
                "You can also say \"open YouTube\". Maya sees app names only so she can launch them.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedButton(onClick = onPickFile, modifier = Modifier.padding(top = 8.dp)) { Text("Read a text file…") }
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                label = { Text("Find an app") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(shown, key = { it.packageName }) { app ->
                    Box(Modifier.fillMaxWidth().clickable { onLaunch(app) }.padding(vertical = 14.dp)) { Text(app.label, fontSize = 16.sp) }
                    HorizontalDivider()
                }
            }
        }
    }
}
