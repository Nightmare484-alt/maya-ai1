package com.maya.assistant.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import com.maya.assistant.vm.Phase
import com.maya.assistant.vm.UiState
import kotlin.math.sin

private val LedPink = Color(0xFFFF4FD8)
private val LedGreen = Color(0xFF3DFFB0)
private val LedAmber = Color(0xFFFFB02E)
private val LedRed = Color(0xFFFF4D4D)

private enum class Led { IDLE, LISTENING, THINKING, SPEAKING, BACKGROUND, ERROR }

private fun ledFor(s: UiState) = when {
    s.error != null || s.phase == Phase.ERROR -> Led.ERROR
    s.backgroundActive -> Led.BACKGROUND
    else -> when (s.phase) {
        Phase.LISTENING -> Led.LISTENING
        Phase.THINKING -> Led.THINKING
        Phase.SPEAKING -> Led.SPEAKING
        else -> Led.IDLE
    }
}

/** Local-only animated LED glow around the screen edges; colour and speed follow the real state. */
@Composable
fun LedBorder(state: UiState, modifier: Modifier = Modifier.fillMaxSize()) {
    val mode = ledFor(state)
    val speedMs = when (mode) {
        Led.IDLE -> 9000; Led.LISTENING -> 3000; Led.THINKING -> 1400
        Led.SPEAKING -> 2200; Led.BACKGROUND -> 4000; Led.ERROR -> 2600
    }
    val base by animateColorAsState(
        when (mode) {
            Led.IDLE -> MayaBlue; Led.LISTENING -> LedGreen; Led.THINKING -> LedAmber
            Led.SPEAKING -> MayaViolet; Led.BACKGROUND -> MayaCyan; Led.ERROR -> LedRed
        }, tween(500), label = "ledBase",
    )
    val t = rememberInfiniteTransition(label = "led")
    val angle by t.animateFloat(0f, 360f, infiniteRepeatable(tween(speedMs, easing = LinearEasing)), label = "ledAngle")
    val beat by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(if (mode == Led.SPEAKING) 450 else 1100, easing = LinearEasing), RepeatMode.Reverse),
        label = "ledBeat",
    )
    Canvas(modifier) {
        val pulse = when (mode) {
            Led.IDLE -> 0.55f
            Led.ERROR -> 0.5f + 0.5f * beat
            else -> 0.7f + 0.3f * sin(beat * Math.PI.toFloat())
        }
        val colors = listOf(base, LedPink, MayaCyan, LedGreen, base)
        val brush = Brush.sweepGradient(colors, center)
        val radius = CornerRadius(size.minDimension * 0.08f)
        // Layered strokes: wide soft halo + crisp core = LED glow without blur effects.
        listOf(26f to 0.10f, 14f to 0.18f, 6f to 0.35f, 2.5f to 0.95f).forEach { (w, a) ->
            rotate(angle, center) {
                drawRoundRect(
                    brush = brush, topLeft = Offset(w / 2, w / 2),
                    size = Size(size.width - w, size.height - w),
                    cornerRadius = radius, style = Stroke(w), alpha = a * pulse,
                )
            }
        }
    }
}
