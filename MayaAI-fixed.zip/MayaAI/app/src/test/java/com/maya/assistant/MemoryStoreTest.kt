package com.maya.assistant

import com.maya.assistant.data.FileMemoryStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class MemoryStoreTest {
    @get:Rule val tmp = TemporaryFolder()

    private fun store(max: Int = 100, len: Int = 300) =
        FileMemoryStore(tmp.root.resolve("m.json"), maxNotes = max, maxLength = len)

    @Test fun addPersistsAcrossInstances() {
        store().add("I like tea")
        assertEquals(listOf("I like tea"), store().all().map { it.text })
    }

    @Test fun blankIsRejected() {
        assertNull(store().add("   "))
        assertTrue(store().all().isEmpty())
    }

    @Test fun duplicatesIgnoringCaseAreMerged() {
        val s = store()
        s.add("Likes tea"); s.add("likes TEA")
        assertEquals(1, s.all().size)
    }

    @Test fun truncatesAndCollapsesWhitespace() {
        val n = store(len = 10).add("a   b   c   d   e   f   g")
        assertEquals("a b c d e ", n!!.text)
    }

    @Test fun dropsOldestWhenFull() {
        val s = store(max = 2)
        s.add("one"); s.add("two"); s.add("three")
        assertEquals(listOf("two", "three"), s.all().map { it.text })
    }

    @Test fun removeAndClear() {
        val s = store()
        val a = s.add("a")!!; s.add("b")
        s.remove(a.id)
        assertEquals(listOf("b"), s.all().map { it.text })
        s.clear()
        assertTrue(store().all().isEmpty())
    }

    @Test fun corruptFileStartsEmptyInsteadOfCrashing() {
        tmp.root.resolve("m.json").writeText("{not json")
        val s = store()
        assertTrue(s.all().isEmpty())
        assertEquals(1, s.apply { add("ok") }.all().size)
    }
}
